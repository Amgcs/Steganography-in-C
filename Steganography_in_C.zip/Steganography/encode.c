#include <stdio.h>  // Includes standard input/output function
#include <string.h> // Includes string handling functions
#include "encode.h" // Includes the function declarations and structures
#include "types.h"  // Contains custom data type definitions
#include "common.h" // Includes constants, macros, and common functions shared between encode and decode modules


// This function reads and checks the command-line arguments.
// It makes sure the source image is .bmp and the secret file has an extension.
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    // Store the source image name
    encInfo->src_image_fname = argv[2];

    // Check if the source image has .bmp extension
    char *ext = strrchr(encInfo->src_image_fname, '.');
    if (!ext || strcmp(ext, ".bmp") != 0)   //checking if the user given src file is valid or not
    {
        printf("ERROR: Source image must be .bmp\n");
        return e_failure;
    }

    // Store the secret file name
    encInfo->secret_fname = argv[3];

    // Get the extension of secret file (like .txt)
    char *dot = strrchr(encInfo->secret_fname, '.');
    if (!dot)   //checks if user given secret data file is valid or not
    {
        printf("ERROR: Secret file extension missing\n");   //error message
        return e_failure;
    }


    // Save the extension into structure
    strcpy(encInfo->extn_secret_file, dot);     

    // If the user does not give output name, use default "stego.bmp"
    if(argv[4]==NULL) 
    {
        encInfo->stego_image_fname="stego.bmp";     
    }
    else
        {
            encInfo->stego_image_fname=argv[4];
        }
    return e_success;
}


// This function opens 3 important files:
// - source image (read mode)
// - secret file (read mode)
// - stego image (write mode)
Status open_files(EncodeInfo *encInfo)
{
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "rb");    
    if (!encInfo->fptr_src_image)
    {
        printf("ERROR: Cannot open source bmp\n");
        return e_failure;
    }

    encInfo->fptr_secret = fopen(encInfo->secret_fname, "rb");
    if (!encInfo->fptr_secret)
    {
        printf("ERROR: Cannot open secret file\n");
        return e_failure;
    }

    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "wb");
    if (!encInfo->fptr_stego_image)
    {
        printf("ERROR: Cannot create stego file\n");
        return e_failure;
    }

    return e_success;
}


// This function reads width and height from BMP header (offset 18).
// Image size = width * height * 3 (because each pixel has 3 bytes RGB).
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;

    fseek(fptr_image, 18, SEEK_SET);    //point the file pointer to 18 th pos to get width  and height
    fread(&width, sizeof(int), 1, fptr_image);
    fread(&height, sizeof(int), 1, fptr_image);


    return width * height * 3;  //return available bytes
}


// This function simply returns size of the secret file using ftell().
uint get_file_size(FILE *fptr)
{
    fseek(fptr, 0, SEEK_END);   //to get total bytes of secret data
    long size = ftell(fptr);    
    rewind(fptr);       //take back the pointer to starting pos of secret data
    return size;
}


// This function checks whether the image has enough space to hide:
// magic string, extension size, extension, secret file size and secret data.
Status check_capacity(EncodeInfo *encInfo)      
{
    encInfo->image_capacity = get_image_size_for_bmp(encInfo->fptr_src_image);
    encInfo->size_secret_file = get_file_size(encInfo->fptr_secret);

    // Total bits required for storing all data
    long total_bits = strlen(MAGIC_STRING) * 8 
                    + 32 
                    + strlen(encInfo->extn_secret_file) * 8 
                    + 32 
                    + encInfo->size_secret_file * 8;

    if (encInfo->image_capacity < total_bits)
    {
        printf("ERROR: Image too small!\n");
        return e_failure;
    }

    return e_success;
}


// This function hides one byte (8 bits) into 8 bytes of image data.
// It changes only the LSB of each image byte.
Status encode_byte_to_lsb(char data, char *image_buffer)
{
    for (int i = 0; i < 8; i++)
    {
        int bit = (data >> (7 - i)) & 1;   // extract each bit of secret byte
        image_buffer[i] = (image_buffer[i] & 0xFE) | bit; // change only LSB
    }
    return e_success;
}


// This function hides many bytes (magic / extension / data) into the image.
Status encode_data_to_image(char *data, int size,
                            FILE *src, FILE *dest)
{
    char buf[8];

    for (int i = 0; i < size; i++)
    {
        // Read 8 bytes from source image
        fread(buf, 8, 1, src);

        // Encode one byte of data into these 8 bytes
        encode_byte_to_lsb(data[i], buf);

        // Write modified bytes to stego image
        fwrite(buf, 8, 1, dest);
    }

    return e_success;
}


// This function encodes 32-bit integer (size value) using 32 image bytes.
Status encode_size_to_lsb(int value, FILE *src, FILE *dest)
{
    unsigned char buf[32];

    // Read 32 bytes from image
    fread(buf, 1, 32, src);

    // Store 32 bits of integer into LSBs
    for (int i = 0; i < 32; i++)
    {
        int bit = (value >> (31 - i)) & 1;
        buf[i] = (buf[i] & 0xFE) | bit;
    }

    fwrite(buf, 1, 32, dest);
    return e_success;
}


// This simply copies first 54 bytes of BMP header as it is.
Status copy_bmp_header(FILE *src, FILE *dest)
{
    unsigned char header[54];

    fread(header, 1, 54, src);  
    fwrite(header, 1, 54, dest);

    return e_success;
}


// Encode magic string into image
Status encode_magic_string(const char *magic, EncodeInfo *encInfo)
{
    encode_data_to_image(
        (char *)magic,
        strlen(magic),
        encInfo->fptr_src_image,
        encInfo->fptr_stego_image);

        return e_success;
}


// Encode file extension like ".txt"
Status encode_secret_file_extn(const char *ext, EncodeInfo *encInfo)
{
    encode_data_to_image(
        (char *)ext,
        strlen(ext),
        encInfo->fptr_src_image,
        encInfo->fptr_stego_image);

        return e_success;
}


// Encode size of the secret file (32 bits)
Status encode_secret_file_size(long size, EncodeInfo *encInfo)
{
    encode_size_to_lsb(
        (int)size,
        encInfo->fptr_src_image,
        encInfo->fptr_stego_image);

        return e_success;
}


// This function hides the actual secret file data inside the image.
Status encode_secret_file_data(EncodeInfo *encInfo)
{
    for (long i = 0; i < encInfo->size_secret_file; i++)
    {
        // Read 1 byte from the secret file
        fread(&encInfo->secret_data, 1, 1, encInfo->fptr_secret);

        // Read next 8 bytes from image
        fread(encInfo->image_data, 8, 1, encInfo->fptr_src_image);

        // Hide this secret byte into image bytes
        encode_byte_to_lsb(encInfo->secret_data, encInfo->image_data);

        // Write encoded bytes in stego image
        fwrite(encInfo->image_data, 8, 1, encInfo->fptr_stego_image);
    }

    return e_success;
}


// Copy the rest of the image (pixels after encoding is finished)
Status copy_remaining_img_data(FILE *src, FILE *dest)
{
    char ch;
    while (fread(&ch, 1, 1, src) == 1)
        fwrite(&ch, 1, 1, dest);

    return e_success;
}


// This is the main encoding flow.
// It calls all the other functions step by step.
Status do_encoding(EncodeInfo *encInfo)
{
    if (open_files(encInfo) == e_failure)
        return e_failure;

    if (check_capacity(encInfo) == e_failure)
        return e_failure;

    // Copy BMP header as it is
    copy_bmp_header(encInfo->fptr_src_image, encInfo->fptr_stego_image);

    // Encode magic string (#*)
    encode_magic_string(MAGIC_STRING, encInfo);

    // Encode extension size
    encode_size_to_lsb(strlen(encInfo->extn_secret_file),
                       encInfo->fptr_src_image,
                       encInfo->fptr_stego_image);

    // Encode extension characters
    encode_secret_file_extn(encInfo->extn_secret_file, encInfo);

    // Encode file size
    encode_secret_file_size(encInfo->size_secret_file, encInfo);

    // Encode actual secret file bytes
    encode_secret_file_data(encInfo);

    // Copy leftover image data
    copy_remaining_img_data(encInfo->fptr_src_image, encInfo->fptr_stego_image);
    return e_success;
}

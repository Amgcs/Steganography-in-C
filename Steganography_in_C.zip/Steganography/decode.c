#include <stdio.h>  // Includes standard input/output functions
#include <string.h> // Includes string handling functions
#include <stdlib.h>     //include standard library functions
#include "types.h"  // Contains custom data type definitions
#include "decode.h" // Includes the function declarations and structures related to decoding operations
#include "common.h"  // Includes constants, macros, and common functions shared between encode and decode modules


/* This function checks the command-line arguments for decoding.
 * It makes sure the input file is a .bmp file.
 * It also decides the name of the output file.
 */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
    char *pt = strrchr(argv[2], '.');   // find last dot to get extension
    if (pt == NULL || strcmp(pt, ".bmp") != 0)
    {
        printf("Error! File must end with .bmp\n");
        return e_failure;
    }
    decInfo->stego_image_fname = argv[2];

    // If user doesn't give output file name, use default
    if (argv[3] == NULL)
    {
        decInfo->secret_fname = "output.txt";
        return e_success;
    }

    // If user gives output name, add .txt to it
    char *str = argv[3];
    str = strtok(str, ".");
    decInfo->secret_fname = str;
    strcat(decInfo->secret_fname, ".txt");

    printf("All done\n");
    return e_success;
}

/* This function opens the stego image (input)
 * and creates the output file where secret data will be written.
 */
Status open_decode_files(DecodeInfo *decInfo)
{
    decInfo->fptr_stego_image = fopen(decInfo->stego_image_fname, "rb");
    if (decInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        printf("Error! Unable to open stego image file: %s\n", decInfo->stego_image_fname);
        return e_failure;
    }

    // Move file pointer to pixel data (after BMP header)
    if (fseek(decInfo->fptr_stego_image, 54, SEEK_SET) != 0)
    {
        printf("Error! Failed to seek stego image.\n");
        fclose(decInfo->fptr_stego_image);
        return e_failure;
    }

    decInfo->fptr_secret = fopen(decInfo->secret_fname, "wb");
    if (decInfo->fptr_secret == NULL)
    {
        perror("fopen");
        printf("Error! Unable to create output secret file: %s\n", decInfo->secret_fname);
        fclose(decInfo->fptr_stego_image);
        return e_failure;
    }

    printf("Open done\n");
    return e_success;
}

/* This function reads 8 bytes and extracts 1 byte from their LSBs */
unsigned char decode_byte_from_lsb(const unsigned char *buffer)
{
    unsigned char byte = 0;
    for (int i = 0; i < 8; i++)
    {
        byte = (byte << 1) | (buffer[i] & 1);   // take only LSB
    }
    return byte;
}

/* This extracts a 32-bit integer (file size) from LSBs */
unsigned int decode_size_from_lsb(const unsigned char *buffer)
{
    unsigned int size = 0;
    for (int i = 0; i < 32; i++)
    {
        size = (size << 1) | (buffer[i] & 1);
    }
    return size;
}

/* This function checks if magic string "#*" is present or not */
Status decode_magic_string(DecodeInfo *decInfo)
{
    unsigned char buffer[8];
    char decoded_magic[3] = {0};

    const size_t magic_len = strlen(MAGIC_STRING);  //getting length of magic string

    for (size_t i = 0; i < magic_len; i++)
    {
        if (fread(buffer, 8, 1, decInfo->fptr_stego_image) != 1)        //reading magic string from stego.bmp
        {
            printf("Error! Failed to read image buffer while decoding magic string.\n");
            return e_failure;
        }

        decoded_magic[i] = (char)decode_byte_from_lsb(buffer);
    }

    

    if (strcmp(decoded_magic, MAGIC_STRING) != 0)   //comparing magic string
    {
        printf("Error! Magic string mismatch.\n");
        return e_failure;
    }

    return e_success;
}

/* Read 32 bits from LSB to get the extension length */
Status decode_secret_file_extn_size(DecodeInfo *decInfo)
{
    unsigned char buffer[32];   //buffer to copy data from stego.bmp file

    if (fread(buffer, 32, 1, decInfo->fptr_stego_image) != 1)   //reading 32 bytes from stego.bmp 
    {
        printf("Error! Failed to read data while decoding extension size.\n");
        return e_failure;
    }

    unsigned int extn_size = decode_size_from_lsb(buffer);  //getting extention size
    decInfo->extn_size = (int)extn_size;

    if (decInfo->extn_size <= 0 || decInfo->extn_size > (int)sizeof(decInfo->extn_secret_file) - 1)
    {
        printf("Error! Decoded extension size is invalid: %d\n", decInfo->extn_size);
        return e_failure;
    }

    return e_success;
}

/* Read extension characters from LSB (like 't', 'x', 't') */
Status decode_secret_file_extn(DecodeInfo *decInfo)
{
    unsigned char buffer[8];

    for (int i = 0; i < decInfo->extn_size; i++)
    {
        if (fread(buffer, 8, 1, decInfo->fptr_stego_image) != 1)    //copying extention from stego
        {
            printf("Error! Failed to read extension data.\n");
            return e_failure;
        }

        decInfo->extn_secret_file[i] = (char)decode_byte_from_lsb(buffer);  //saves the extension to structure
    }

    decInfo->extn_secret_file[decInfo->extn_size] = '\0';   //adding null value
    return e_success;   
}

/* Read file size of the hidden text file */
Status decode_secret_file_size(DecodeInfo *decInfo)
{
    unsigned char buffer[32];

    if (fread(buffer, 32, 1, decInfo->fptr_stego_image) != 1)       //reading 32 bytes from stego
    {
        printf("Error! Failed to read image buffer.\n");
        return e_failure;
    }

    unsigned int size = decode_size_from_lsb(buffer);
    decInfo->size_secret_file = (int)size;

    if (decInfo->size_secret_file < 0)
    {
        printf("Error! Invalid secret file size decoded: %d\n", decInfo->size_secret_file);
        return e_failure;
    }

    printf("Decoded secret size = %d\n", decInfo->size_secret_file);
    return e_success;
}

/* This function reads each hidden byte and writes it to output file */
Status decode_secret_file_data(DecodeInfo *decInfo)
{
    unsigned char buffer[8];
    unsigned char decoded_byte;

    for (int i = 0; i < decInfo->size_secret_file; i++)
    {
        if (fread(buffer, 8, 1, decInfo->fptr_stego_image) != 1)    //copying 8 bytes from stego
        {
            printf("Error! Failed to read image data while decoding secret file data.\n");
            return e_failure;
        }

        decoded_byte = decode_byte_from_lsb(buffer);

        if (fwrite(&decoded_byte, 1, 1, decInfo->fptr_secret) != 1)
        {
            printf("Error! Failed to write output to secret file.\n");
            return e_failure;
        }
    }

    fclose(decInfo->fptr_stego_image);
    fclose(decInfo->fptr_secret);

    return e_success;
}

/* Main function that calls all decoding steps in order */
Status do_decoding(DecodeInfo *decInfo)
{
    printf("\n-----DECODING-----\n\n");

    if (open_decode_files(decInfo) == e_failure)
    {
        printf("Failed to open files.\n");
        return e_failure;
    }
    printf("Successfully opened files.\n");

    if (decode_magic_string(decInfo) == e_failure)
    {
        printf("Failed to decode magic string.\n");
        return e_failure;
    }
    printf("Successfully decoded magic string.\n");

    if (decode_secret_file_extn_size(decInfo) == e_failure)
    {
        printf("Failed to decode secret file extension size.\n");
        return e_failure;
    }
    printf("Successfully decoded secret file extension size.\n");

    if (decode_secret_file_extn(decInfo) == e_failure)
    {
        printf("Failed to decode secret file extension.\n");
        return e_failure;
    }
    printf("Successfully decoded secret file extension.\n");

    if (decode_secret_file_size(decInfo) == e_failure)
    {
        printf("Failed to decode secret file size.\n");
        return e_failure;
    }
    printf("Successfully decoded secret file size.\n");

    if (decode_secret_file_data(decInfo) == e_failure)
    {
        printf("Failed to decode secret file data.\n");
        return e_failure;
    }
    printf("Successfully decoded secret file data.\n");

    printf("\nDECODING COMPLETED SUCCESSFULLY!\n");
    return e_success;
}

/*
Name : Amegh C S 
Date :05/12/2025
Description: Steganography
*/

#include <stdio.h>  //includes standard i/o functions
#include "encode.h" //includes functions for encode.c
#include "types.h"  //includes special data types
#include "decode.h" //includes functions for decode.c
#include<string.h>  //includes string handling functions

int main(int argc,char *argv[])
{
    EncodeInfo encInfo; //creating encode structure
    DecodeInfo decInfo; //crating decode structure

    //if cmd argument count is <4 -> print usage msg
  

    int ret=check_operation_type(argv);
    if(ret == 0)
    {
        if(argc<4)
        {
            printf("Usage : %s -e <src.bmp> <secret.txt> [<output.bmp>]\n",argv[0]);
            return 1;
        }
        printf("Selected encode.....\n");
        /*to validate cma have all arguments essential for encoding*/
        int check=read_and_validate_encode_args(argv,&encInfo);
        if(check==0)
        {
            printf("All files are valid.....\n");
        }
        /*make open all files*/
        open_files(&encInfo);
        
        int capable=check_capacity(&encInfo);
        if(capable==1)
        {
            printf("Image size is not enough!\n");
            return 1;
        }  
        
        int enc_check=do_encoding(&encInfo);
        if(enc_check!=1)
        {
            printf("Encoding successfull\n");
        }

    }

    else if(ret==1)
    {
        printf("Selected decode.....\n");
        int check=read_and_validate_decode_args(argv,&decInfo);
        if(check==0)
        {
            printf("All files are valid.....\n");
        }
        /*make open all files*/
        printf("1\n");
        //int check_file=open_decode_files(&decInfo);

        /*if((decode_magic_string(&decInfo))==1)
        {
            return 0;
        }*/ 
        do_decoding(&decInfo);       

    } 

    //decode ,invalid=> usage message about cma
    return 0;
}

OperationType check_operation_type(char *argv[])
{
    if (strcmp(argv[1], "-e") == 0) //compares if user selected encode
        return e_encode;

    if(strcmp(argv[1],"-d")==0) //compares if user selected decode
        return e_decode;

    return e_unsupported;
}
